sap.ui.define([], function() {
	"use strict";

	return {
		/**
		 * Rounds the currency value to 2 digits
		 *
		 * @public
		 * @param {string} sValue value to be formatted
		 * @returns {string} formatted currency value with 2 digits
		 */
		currencyValue: function(sValue) {
			if (!sValue) {
				return "";
			}

			return parseFloat(sValue).toFixed(2);
		},

		formatColorChange: function(sValue, oEvent) {
			var oItems = this._oPopover.getContent()[0].getItems();
			if (oItems.length > 0) {
				var oItem = oItems[(oItems.length) - 1];
				var oText = oItem.getCells()[1];
				if (sValue == "request") {
					oText.addStyleClass("applyOrangeColor");
				} else if (sValue == "complaint") {
					oText.addStyleClass("applyRedColor");
				} else if(sValue == "compliment"){
					oText.addStyleClass("applyGreenColor");
				}
			}
			return sValue;
		}
	};

});