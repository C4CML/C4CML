sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/demo/LeadsClassification/model/formatter"
], function (Controller, formatter) {
	"use strict";

	return Controller.extend("com.sap.demo.LeadsClassification.controller.main", {

		formatter: formatter,

		onInit: function () {
			var oLeadTicketJSONModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oLeadTicketJSONModel);
			this.getLeadsDataOnline();
		},

		getLeadsDataOnline: function () {
			var sURI = "/C4C_ML/sap/c4c/odata/v1/c4codata/";
			var oModel = new sap.ui.model.odata.ODataModel(sURI, true);
			this.createLeadData(oModel);
		},

		createLeadData: function (oModel) {
			var dialog = new sap.m.BusyDialog({
				text: 'Loading Leads...'
			});
			dialog.open();
			var aServiceTicketData = [];
			var that = this;
			oModel.read("/ServiceRequestCollection", {
				urlParameters: {
					"$orderby": "ID desc",
					"$filter": "ServiceRequestLifeCycleStatusCode eq '1' or ServiceRequestLifeCycleStatusCode eq '2'",
					"$expand": "ServiceRequestDescription"
				},
				success: function (oResults) {
					var aServiceCollections = oResults.results;
					for (var i = 0; i < aServiceCollections.length; i++) {
						var oServiceTicket = aServiceCollections[i];
						var aServiceRequestDescription = oServiceTicket.ServiceRequestDescription;
						if (aServiceRequestDescription) {
							if (aServiceRequestDescription.length > 0) {
								var sServiceTicketLastText = aServiceRequestDescription[aServiceRequestDescription.length - 1].Text;
								aServiceTicketData.push({
									"TicketID": oServiceTicket.ID,
									"TicketText": sServiceTicketLastText
								});
							}
						}
					}
					dialog.close();
					that.getLeadTicketDataFromServiceTickets(oModel, aServiceTicketData, that);
				}
			});
		},
		getLeadTicketDataFromServiceTickets: function (oModel, aServiceTickets, that) {
			var dialog = new sap.m.BusyDialog({
				text: 'Loading Leads...'
			});
			dialog.open();
			var aLeadTicketData = [];
			var oLeadTicketJSONModel = that.getView().getModel();
			oModel.read("/LeadBusinessDocumentReferenceCollection", {
				urlParameters: {
					"$orderby": "ID desc",
					"$filter": "TypeCode eq '118'",
					"$expand": "Lead"
				},
				success: function (aResultData) {
					for (var i = 0; i < aResultData.results.length; i++) {
						//Creating a JSON model which needs to be binded to main and detail view
						for (var j = 0; j < aServiceTickets.length; j++) {
							var sTicketID = aResultData.results[i].ID;
							var oServiceTicket = aServiceTickets[j];
							if (oServiceTicket.TicketID === sTicketID) {
								aLeadTicketData.push({
									"LeadID": aResultData.results[i].Lead.LeadID,
									"TicketDetails": oServiceTicket
								});
							}
						}
					}
					dialog.close();
					oLeadTicketJSONModel.setData({
						"LeadTickets": aLeadTicketData
					});
				}
			});
		},

		classifyLeads: function (oEvent) {
			var oModel = this.getView().getModel();
			this.callMLServiceFromAPIHub(oModel);
		},

		callMLServiceFromAPIHub: function (oLeadsModel) {
			var sHeaders = {
				"Content-Type": "application/json",
				"Accept": "application/json",
				"APIKey": "3yaaozAkQyod0GkSnuUgz5fwSWDXyRjs"
			};
			var oModel = new sap.ui.model.json.JSONModel();
			var oData = {
				"business_object": "ticket",
				"messages": this.createDataSetForMLService(oLeadsModel),
				"options": [{
					"classification_keyword": true
				}]
			};

			oModel.loadData("https://sandbox.api.sap.com/ml/sti/classification/text/classify", JSON.stringify(oData), true, "POST", null, false,
				sHeaders);
			var oResponseData;
			var that = this;
			oModel.attachRequestCompleted(function (oEvent) {
				oResponseData = oEvent.getSource().oData;
				that.filterLeadsByClassificaion(oResponseData, oLeadsModel);
			});
		},

		createDataSetForMLService: function (oLeadsModel) {
			var aResults = oLeadsModel.getData().LeadTickets;
			var textArray = [];
			for (var i = 0; i < aResults.length; i++) {
				textArray.push({
					"id": aResults[i].TicketDetails.TicketID,
					"contents": [{
						"field": "text",
						"value": aResults[i].TicketDetails.TicketText
					}]
				});
			}
			return textArray;
		},
		filterLeadsByClassificaion: function (oResponseData, oLeadsModel) {
			var oLeadsData = oLeadsModel.getData().LeadTickets;
			var aFilteredData = [];
			var aResults = oResponseData.results;
			for (var i = 0; i < aResults.length; i++) {
				var sClassification = aResults[i].classification[0].value;
				if ("complaint" === sClassification || "request" === sClassification) {
					var oLead = oLeadsData[i];
					oLead.TicketDetails.Classification = sClassification;
					aFilteredData.push(oLead);
				}
			}
			oLeadsModel.setData({
				"LeadTickets": aFilteredData
			});
		}
	});
});