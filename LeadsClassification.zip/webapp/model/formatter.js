sap.ui.define([], function() {
	"use strict";

	return {
	
		setClassificationIcon: function(sValue) {
			if(sValue === "complaint"){
				return "sap-icon://alert";	
			}else if(sValue === "request"){
				return "sap-icon://incident";	
			}
			return "sap-icon://activity-items";
		},
		
		setInfoState: function(sValue) {
			if(sValue === "complaint"){
				return "Error";	
			}else if(sValue === "request"){
				return "Warning";	
			}
			return "Success";
		},
		
		setTicketText : function(sClassification, sTicketText){
			if(sClassification === "complaint"){
				return "Complaint: " + sTicketText;	
			}else if(sClassification === "request"){
				return "Request: " + sTicketText;
			}
			return "Comment: " + sTicketText;
		}
	};

});